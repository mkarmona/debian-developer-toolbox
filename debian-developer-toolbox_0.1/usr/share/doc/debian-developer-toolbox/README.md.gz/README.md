# debian-developer-toolbox
Minimal list of debian packages that every developer must have
